import java.util.Scanner;

class Main{
	public static void main (String[] args){
        Scanner input = new Scanner(System.in);
        int ax = input.nextInt();
        int ay = input.nextInt();
        int ax2 = input.nextInt();
        int ay2 = input.nextInt();
        Point p1 = new Point(ax,ay);
        Point p2 = new Point(ax2,ay2);
        p1.print();
        p2.print();
        System.out.println(p1.isOrigin());
        System.out.println(p1.isEqual(p2));
        if (p1.getAbsis() == 0 && (p1.getOrdinat() == 0)) {
            System.out.println("-1");
            }
        else {
            System.out.println(p1.kuadran());
        }
        Point origin = new Point();
        System.out.println(p1.distance(origin));
        p1.translate(p2);
        p1.print();
        int ax3 = input.nextInt();
        int ay3 = input.nextInt();
        p1.translate(ax3, ay3);
        p1.print();
    }
}