public class SingingAnimal {
	protected int legs;
	protected String name;
	protected String voice;

	public SingingAnimal(int legs, String name, String voice) {
		this.legs = legs;
		this.name = name;
		this.voice = voice;
	}

	public int getLegs() {
		return legs; 
	}

	public String getName() {
		return name; 
	}
	
	public String getVoice() {
		return voice; 
	}

	public void setLegs(int l) {
		legs = l;
	}

	public void setName(String n) {
		name = n;
	}

	public void setVoice(String v) {
		voice = v;
	}

	public void sing() {
		System.out.println(voice);
	}

	public void dance() {
		System.out.println("I am dancing using my "+legs+" legs");
	}
} 