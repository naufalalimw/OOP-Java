interface Movie {
    public String getType();
    public String getName();
  }
  
