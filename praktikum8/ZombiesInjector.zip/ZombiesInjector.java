import java.util.*;
import java.lang.*;
import java.lang.reflect.*;

class ZombiesInjector {
  static Object inject(Class clas) throws Exception {
    Object object;
    Constructor cons = clas.getConstructor(clas); //ambil cons
    object = cons.newInstance(); // instansiasi
    // TODO: Construct the class here
    try {
      // TODO: Set zombies field in the created object to new ArrayList<String>() here.
      Class c = object.getClass();
      Field f = c.getField("zombies");
      f.set(object,new ArrayList<String>());
      return object;
    } catch (Exception ex) {
      // TODO: Exception will happen if there are no zombies variable
      //       handle it here
      return object;
    } 
  }
}