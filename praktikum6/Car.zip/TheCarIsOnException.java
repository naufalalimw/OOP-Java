public class TheCarIsOnException extends Exception {
    public TheCarIsOnException(){};
    public String getMessage(){
        return "Mobil sudah menyala";
    };
}