public class FuelException extends Exception {
    private String fuel;
    public FuelException(String a){
        this.fuel = a;
    };
    public String getMessage(){
        return "Bensin jenis "+fuel+" tidak sesuai";
    };
}