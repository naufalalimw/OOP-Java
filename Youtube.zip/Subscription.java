interface Subscription {
    public String getType();
    public int getBillAmount();
  }
  